package com.ms.service;

import com.ms.dao.model.Resources;

/**
 * Created by wangbin on 2016/7/8.
 */
public interface ResourcesService extends ICommonService<Resources>{
}
