package com.ms.boss.config;

/**
 * Created by xiao on 2017/2/17.
 */
public interface LogTypeConstant {

    public final String ACCOUNTBILL = "账单模块";
    public final String CATEGORY = "品种模块";
    public final String GENERAL="通用模块";
    public final String MEMBER="后台用户模块";
    public final String PAYRECORD="支付流水模块";
    public final String ORDER="订单模块";
    public final String QUOTATION="报价单模块";
    public final String SENDSAMPLE="寄样单模块";
    public final String SUPPLIER="供应商模块";
    public final String ROLE="角色模块";
    public static final String COMMODITY = "商品模块";

    public static final String USER = "用户模块";

    public static final String SETTING = "配置模块";




}
