package com.ms.dao.vo;

import com.ms.dao.model.SupplierCommodity;

public class SupplierCommodityVo extends SupplierCommodity{

}