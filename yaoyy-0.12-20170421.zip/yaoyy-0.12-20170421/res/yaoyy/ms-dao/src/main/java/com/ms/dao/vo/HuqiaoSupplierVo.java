package com.ms.dao.vo;

import com.ms.dao.model.HuqiaoSupplier;

public class HuqiaoSupplierVo extends HuqiaoSupplier{

}