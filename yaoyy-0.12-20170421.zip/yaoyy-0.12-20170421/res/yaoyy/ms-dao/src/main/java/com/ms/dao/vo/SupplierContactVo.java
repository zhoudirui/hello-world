package com.ms.dao.vo;

import com.ms.dao.model.SupplierContact;

public class SupplierContactVo extends SupplierContact{

}