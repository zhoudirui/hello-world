package com.ms.dao.vo;

import com.ms.dao.model.SupplierChoice;

public class SupplierChoiceVo extends SupplierChoice{

}