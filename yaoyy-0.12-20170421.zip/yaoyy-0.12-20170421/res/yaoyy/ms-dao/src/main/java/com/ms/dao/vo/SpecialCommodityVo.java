package com.ms.dao.vo;

import com.ms.dao.model.SpecialCommodity;

public class SpecialCommodityVo extends SpecialCommodity{

}