package com.ms.dao.vo;

import com.ms.dao.model.OrderInvoice;

public class OrderInvoiceVo extends OrderInvoice{

}