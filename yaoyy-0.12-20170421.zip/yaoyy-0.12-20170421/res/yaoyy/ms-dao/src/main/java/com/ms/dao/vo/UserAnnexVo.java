package com.ms.dao.vo;

import com.ms.dao.model.UserAnnex;

public class UserAnnexVo extends UserAnnex{

}