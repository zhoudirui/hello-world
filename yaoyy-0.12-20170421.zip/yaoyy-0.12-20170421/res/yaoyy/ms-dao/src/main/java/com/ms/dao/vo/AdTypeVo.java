package com.ms.dao.vo;

import com.ms.dao.model.AdType;

public class AdTypeVo extends AdType{

}