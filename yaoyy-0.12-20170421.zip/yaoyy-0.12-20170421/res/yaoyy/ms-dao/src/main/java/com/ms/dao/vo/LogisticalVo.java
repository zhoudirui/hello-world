package com.ms.dao.vo;

import com.ms.dao.model.Logistical;

public class LogisticalVo extends Logistical{

}