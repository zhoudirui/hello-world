package com.ms.dao.vo;

import com.ms.dao.model.Role;


/**
 * Created by burgl on 2016/7/9.
 */
public class RoleVo extends Role{

}
