package com.ms.dao.vo;

import com.ms.dao.model.Gradient;

public class GradientVo extends Gradient{

}