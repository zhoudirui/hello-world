package com.ms.dao.vo;

import com.ms.dao.model.SupplierAnnex;

public class SupplierAnnexVo extends SupplierAnnex{

}