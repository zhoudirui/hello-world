package com.ms.dao.config;

/**
 * Author: koabs
 * 8/15/16.
 */
public @interface AutoMapper {
}
