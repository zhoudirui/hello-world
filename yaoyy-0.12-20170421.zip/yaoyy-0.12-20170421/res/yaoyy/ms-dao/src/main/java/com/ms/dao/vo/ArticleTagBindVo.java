package com.ms.dao.vo;

import com.ms.dao.model.ArticleTagBind;

public class ArticleTagBindVo extends ArticleTagBind{

}