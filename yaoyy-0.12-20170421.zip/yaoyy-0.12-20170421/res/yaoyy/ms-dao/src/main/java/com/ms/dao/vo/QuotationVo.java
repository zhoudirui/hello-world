package com.ms.dao.vo;

import com.ms.dao.model.Quotation;

public class QuotationVo extends Quotation{

}