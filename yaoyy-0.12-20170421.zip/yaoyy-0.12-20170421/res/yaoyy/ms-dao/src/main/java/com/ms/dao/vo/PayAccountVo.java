package com.ms.dao.vo;

import com.ms.dao.model.PayAccount;

public class PayAccountVo extends PayAccount{

}