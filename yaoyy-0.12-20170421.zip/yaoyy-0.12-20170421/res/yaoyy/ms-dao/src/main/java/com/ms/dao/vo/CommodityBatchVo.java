package com.ms.dao.vo;

import com.ms.dao.model.CommodityBatch;

public class CommodityBatchVo extends CommodityBatch{

}