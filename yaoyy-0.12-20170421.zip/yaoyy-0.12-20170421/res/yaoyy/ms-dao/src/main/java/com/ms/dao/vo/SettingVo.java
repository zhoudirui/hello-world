package com.ms.dao.vo;

import com.ms.dao.model.Setting;

public class SettingVo extends Setting{

}