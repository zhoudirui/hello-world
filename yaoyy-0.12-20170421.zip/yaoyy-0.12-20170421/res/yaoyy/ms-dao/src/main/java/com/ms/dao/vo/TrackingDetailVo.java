package com.ms.dao.vo;

import com.ms.dao.model.TrackingDetail;

public class TrackingDetailVo extends TrackingDetail{

}