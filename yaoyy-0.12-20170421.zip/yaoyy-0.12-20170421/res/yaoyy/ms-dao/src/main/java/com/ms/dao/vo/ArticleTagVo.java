package com.ms.dao.vo;

import com.ms.dao.model.ArticleTag;

public class ArticleTagVo extends ArticleTag{

}