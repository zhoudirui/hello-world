package com.ms.dao;

import com.ms.dao.config.AutoMapper;
import com.ms.dao.model.Resources;

@AutoMapper
public interface ResourcesDao extends ICommonDao<Resources>{


	
}
