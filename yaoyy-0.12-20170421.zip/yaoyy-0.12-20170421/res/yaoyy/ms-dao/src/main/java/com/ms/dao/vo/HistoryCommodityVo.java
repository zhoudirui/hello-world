package com.ms.dao.vo;

import com.ms.dao.model.HistoryCommodity;

public class HistoryCommodityVo extends HistoryCommodity{

}