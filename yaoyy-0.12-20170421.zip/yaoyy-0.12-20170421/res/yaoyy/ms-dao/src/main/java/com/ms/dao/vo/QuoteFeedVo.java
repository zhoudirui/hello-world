package com.ms.dao.vo;

import com.ms.dao.model.QuoteFeed;

public class QuoteFeedVo extends QuoteFeed{

}