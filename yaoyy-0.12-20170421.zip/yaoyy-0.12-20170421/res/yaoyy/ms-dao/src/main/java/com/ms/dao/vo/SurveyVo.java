package com.ms.dao.vo;

import com.ms.dao.model.Survey;

public class SurveyVo extends Survey{

}