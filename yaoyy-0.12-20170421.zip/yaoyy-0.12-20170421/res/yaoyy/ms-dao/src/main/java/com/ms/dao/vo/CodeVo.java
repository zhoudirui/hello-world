package com.ms.dao.vo;

import com.ms.dao.model.Code;

public class CodeVo extends Code{

}