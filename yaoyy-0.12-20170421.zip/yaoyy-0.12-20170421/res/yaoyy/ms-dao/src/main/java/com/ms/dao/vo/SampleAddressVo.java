package com.ms.dao.vo;

import com.ms.dao.model.SampleAddress;

public class SampleAddressVo extends SampleAddress{

}