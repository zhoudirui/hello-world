package com.ms.dao.vo;

import com.ms.dao.model.ShippingAddressHistory;

public class ShippingAddressHistoryVo extends ShippingAddressHistory{

}